import cv2
import numpy as np
from matplotlib import pyplot as plt


def fun(img):
    histogram, n = np.histogram(img.ravel(), 256, [0, 256])
    nomalized_histogram = histogram / float(img.size)
    cdf = np.zeros(256)
    cdf[0] = nomalized_histogram[0]
    for i in range(nomalized_histogram.size):
        cdf[i] = nomalized_histogram[i] + cdf[i - 1]
    img = (cdf[img] * 255).astype('uint8')
    return img


img = cv2.imread('dark_cat.jpg')
b, g, r = cv2.split(img)
after_b = fun(b)
after_g = fun(g)
after_r = fun(r)

after = cv2.merge((after_b, after_g, after_r))

cv2.imshow('Origin', img)
cv2.imshow('after', after)
cv2.imwrite('after.jpg', after)
cv2.waitKey()
cv2.destroyAllWindows()

plt.subplot(211)
plt.hist(b.ravel(), 256, [0, 256], histtype='bar', color='b', alpha=0.4)
plt.hist(g.ravel(), 256, [0, 256], histtype='bar', color='g', alpha=0.4)
plt.hist(r.ravel(), 256, [0, 256], histtype='bar', color='r', alpha=0.4)
plt.title("original")

plt.subplot(212)
plt.hist(after_b.ravel(), 256, [0, 256], histtype='bar', color='b', alpha=0.4)
plt.hist(after_g.ravel(), 256, [0, 256], histtype='bar', color='g', alpha=0.4)
plt.hist(after_r.ravel(), 256, [0, 256], histtype='bar', color='r', alpha=0.4)
plt.title("atfer")
plt.savefig('histogram.png')
plt.show()
