import numpy as np
import cv2


def filter(size, sigma):
    center = size // 2  # 1임
    # filter size
    x, y = np.mgrid[0:size, 0:size] - center
    gaussian = (np.exp(-(x ** 2 + y ** 2) / (2 * sigma ** 2))) / (2 ** np.pi * sigma ** 2)
    gaussian /= gaussian.sum()
    print(gaussian)

    return gaussian


img = cv2.imread('orig_img.PNG')
h, w, c = img.shape
cv2.imshow('origin', img)
gaussian = filter(5, 2)
temp = cv2.filter2D(img, -1, gaussian)

rst1 = temp[0:h:2, 0:w:2]
rst2 = temp[0:h:4, 0:w:4]
rst3 = temp[0:h:8, 0:w:8]

cv2.imwrite('rst1.PNG', rst1)
cv2.imwrite('rst2.PNG', rst2)
cv2.imwrite('rst3.PNG', rst3)
cv2.imshow('after_gaussain', temp)
cv2.imshow('1/2', rst1)
cv2.imshow('1/4', rst2)
cv2.imshow('1/8', rst3)

cv2.waitKey()
cv2.destroyAllWindows()
